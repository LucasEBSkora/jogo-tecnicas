#include "DescentIntoMadness.hpp"

int main() {

  DIM::DescentIntoMadness game;

  return 0;
}
