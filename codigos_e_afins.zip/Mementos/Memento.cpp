#include "Memento.hpp"

#include <iostream>

namespace DIM {
  namespace Mementos {

    Memento::Memento() {
      
    }

    Memento::~Memento() {

    }
  
  }
}
